import os
import sys
filename_list=[line for line in os.listdir(sys.argv[1]) if line.endswith('.c')]
parent=os.getcwd()
if os.path.exists(parent+'/'+'build'):
    cmd='rm -rf '+parent+'/'+'build'
    #os.system(cmd)
    pass
else:
    os.makedirs(parent+'/'+'build')
    os.makedirs(parent+'/'+'build/temp')
    os.makedirs(parent+'/'+'build/temp/src')
build=parent+'/'+'build'
build_temp=parent+'/'+'build/temp'
build_temp_src=parent+'/'+'build/temp/src'
gcc='gcc -pthread -fno-strict-aliasing -g -O2 -DNDEBUG -g -fwrapv -O3 -Wall -Wstrict-prototypes -fPIC -I'
gcc1='gcc -pthread -shared -L'
v=sys.version
version='python'+'.'.join(v.split('.')[:2])
print version
python_path=sys.path
for t in python_path:
    if '/lib/' in t:
        path=t.split('/lib/')[0]
        break
print path
for line in filename_list:
    print line
    cmd=gcc+path+'/'+'include'+'/'+version+' -c '+sys.argv[1]+line+' -o '+ build_temp_src+'/'+line.split('.')[0]+'.o'
    cmd2=gcc1+path+'/'+'lib'+' -Wl,-rpath='+path+'/'+'lib'+',--no-as-needed '+build_temp_src+'/'+line.split('.')[0]+'.o -L'+path+'/'+'lib -l'+version+' -o '+build+'/'+line.split('.')[0]+'.so'
    print cmd
    os.system(cmd)
    print cmd2
    os.system(cmd2)
cmd='rm -rf build_temp_src'
os.system(cmd)
cmd='rm -rf build_tmp'
os.system(cmd)
#cmd='cp '+parent+'/'+'script/* '+parent+'/'+'build'
#os.system(cmd)
