import sys
outfile=open(sys.argv[2],'w')
for line in open(sys.argv[1]):
    if line.startswith('@RG'):
        print line.rstrip().split('\t')
        outfile.write(line[1:])
    else:
        continue
outfile.close()
