#!/bin/sh
sample=$1
ref=$2
inputdir=$3
outdir=$4
pathway=$5
samtools=$6
bwa=$7
repeat=$8
thread=$9
readgroup=${10}
mkdir ${outdir}
mkdir ${outdir}/tmp
ln -s ${inputdir}/${sample} ${outdir}/${sample}
ln -s ${inputdir}/${sample}.bai ${outdir}/${sample}.bai 
samtools view -H ${outdir}/${sample} |grep '@RG'>${outdir}/${sample}.head.sam
python ${readgroup}/tique_RG.py ${outdir}/${sample}.head.sam ${outdir}/${sample}.head.sam.readgroup
perl ${pathway}/pre_process.pl -b ${outdir}/${sample} -s 20 -k 10000 -q 5 -t ${thread} -R ${outdir}/${sample}.head.sam.readgroup -W ${bwa} -A ${ref}.fai -I ${ref} 
perl ${pathway}/meerkat.pl -b ${outdir}/${sample} -s 20 -p 3 -d 5 -o 1 -a 0 -u 1 -Q 10 -t ${thread} -W ${bwa} -S ${samtools} -F ${ref}
perl ${pathway}/mechanism.pl -R ${repeat} -b ${outdir}/${sample}

