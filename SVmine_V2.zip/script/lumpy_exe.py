import os
import sys
def lumpy_exe(filename,inputdir,outputdir,pathway_samtools,pathway_lumpy,pathway_exe,samblaster_path):
    if os.path.exists(outputdir):
        pass
    else:
        os.makedirs(outputdir)
    #cmd1=pathway_samtools+'/'+'samtools view -b -F 1294 '+inputdir+'/'+filename+' > '+outputdir+'/'+filename.split('.')[0]+'.discordants.unsorted.bam'
    #cmd2=pathway_samtools+'/'+'samtools view -h '+inputdir+'/'+filename+' | '+pathway_exe+'/'+'/'+'extractSplitReads -i stdin | samtools view -Sb - > '+outputdir+'/'+filename.split('.')[0]+'.splitters.unsorted.bam'
    cmd1=pathway_samtools+'/'+'samtools sort -@ 20 -n '+inputdir+'/'+filename+' '+outputdir+'/'+filename.split('.')[0]+'.nsorted'
    cmd2=pathway_samtools+'/'+'samtools view -h '+outputdir+'/'+filename.split('.')[0]+'.bam'+' | '+samblaster_path+'/'+'samblaster -a -e -d '+outputdir+'/'+filename.split('.')[0]+'.discordant.unsorted.bam -s '+outputdir+'/'+filename.split('.')[0]+'.splitters.unsorted.bam'
    cmd3=pathway_samtools+'/'+'samtools sort '+outputdir+'/'+filename.split('.')[0]+'.discordants.unsorted.bam '+outputdir+'/'+filename.split('.')[0]+'.discordants'
    cmd4=pathway_samtools+'/'+'samtools sort '+outputdir+'/'+filename.split('.')[0]+'.splitters.unsorted.bam '+outputdir+'/'+filename.split('.')[0]+'.splitters'
    cmd5=pathway_lumpy+'/'+'bin'+'/'+'lumpyexpress -B '+inputdir+'/'+filename+' -S '+outputdir+'/'+filename.split('.')[0]+'.splitters.bam -D '+outputdir+'/'+filename.split('.')[0]+'.discordants.bam -o '+outputdir+'/'+filename.split('.')[0]+'.vcf'
    #os.system(cmd1)
    os.system(cmd2)
    os.system(cmd3)
    os.system(cmd4)
    os.system(cmd5)
filename=sys.argv[1]
inputdir=sys.argv[2]
outputdir=sys.argv[3]
pathway_samtools=sys.argv[4]
pathway_lumpy=sys.argv[5]
pathway_exe=sys.argv[6]
samblaster_path=sys.argv[7]
lumpy_exe(filename,inputdir,outputdir,pathway_samtools,pathway_lumpy,pathway_exe,samblaster_path)
