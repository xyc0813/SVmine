import os
import sys
from svmine_exe_v2 import *
main()
