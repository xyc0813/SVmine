from svmine_exe6 import *
import random
import sys
from optparse import OptionParser
import getopt
import time
import os
import ConfigParser
from sys_exe import *
from get_cordinate import *
from collect3 import *
from RD import *
import time
import threading
import thread
from math import log
from time import sleep,ctime
import multiprocessing
from optparse import OptionParser
#from guppy import hpy
def reference1(ref_name):
    print('read refer')
    ref_dic={}
    chr_name=''
    for line in open(ref_name):
        newline=line.rstrip()
        if newline.startswith('>'):
            if chr_name!='':
                ref_dic[chr_name]=tmp_str
            chr_name=newline.split('>')[1]
            tmp_str=''
        else:
            tmp_str=tmp_str+newline
    ref_dic[chr_name]=tmp_str
    print(ref_dic.keys())
    return ref_dic
def main():
    usage = """%prog 
Author: Yuchao Xia	
Description: SVmine.
	"""
    print 'starting at:',ctime()
    time_total=time.time()
    parser = OptionParser(usage)
    parser.add_option("-b", "--bam", dest="bamfile", help="bamfile name",metavar="FILE")
    parser.add_option("-f", "--infile", dest="inputdir", help="input dirctionary",metavar="FILE")
    parser.add_option("-o", "--outfile", dest="outputdir", help="input dirctionary",metavar="FILE")
    parser.add_option("-r", "--ref", dest="ref", help="reference fasta file",metavar="FILE")
    parser.add_option("-l", "--read_length", dest="read_length", help="read length",metavar="INT")
    parser.add_option("-i", "--insert_size", dest="insert_size", help="insert size of paired-end reads",metavar="INT")
    parser.add_option("-d", "--dev", dest="dev", help="standard deviation of insert size",metavar="FLOAT")
    parser.add_option("-c", "--config_file", dest="config_file", help="the pathway of different methods",metavar="FILE")
    parser.add_option("-p", "--paired_support", dest="paired_support", help="the number of paired_end reads support",metavar="INT")
    parser.add_option("-s", "--split_support", dest="split_support", help="the number of split reads support",metavar="INT")
    parser.add_option("-t", "--thread", dest="thread", help="thread number",metavar="INT")
    parser.add_option("-x", "--exclude", dest="exclude_region", help="exclude region",metavar="FILE")
    (opts, args) = parser.parse_args()
    if opts.bamfile is None or opts.ref is None or opts.config_file is None:
        parser.print_help()
    else:
        cf = ConfigParser.ConfigParser()
        cf.read(opts.config_file)
        break_pathway_perl=cf.get("svmine_pathway", "breakdancer_perl")
        break_pathway_cpp=cf.get("svmine_pathway", "breakdancer_cpp")
        meerkat_pathway=cf.get("svmine_pathway", "meerkat")
        delly_pathway=cf.get("svmine_pathway", "delly")
        samtools=cf.get("svmine_pathway", "samtools")
        bwa=cf.get("svmine_pathway", "bwa")
        repeat=cf.get("svmine_pathway", "rmsk")
        ref_dic=cf.get("svmine_pathway", "ref_dic")
        genotype=cf.get("svmine_pathway", "genotype")
        samtools_unique=cf.get("svmine_pathway", "samtools_unique")
        norm=cf.get("svmine_pathway", "normlize")
        readgroup=cf.get("svmine_pathway", "readgroup")
        meerkat_exe_path=cf.get("svmine_pathway", "meerkat_exe_path")
        chr_tag=cf.get("svmine_pathway","chromsome_start_chr")
        bwa_map=cf.get("svmine_pathway","bwa_mapping")
        lumpy=cf.get("svmine_pathway","lumpy")
        multiRG=cf.get("svmine_pathway","multiRG")
        bcftools=cf.get("svmine_pathway","bcftools")
        bamfile=opts.bamfile
        ref=opts.ref
        if opts.inputdir is None:
            inputdir='./'
        else:
            inputdir=opts.inputdir
        if opts.outputdir is None:
            outputdir='./'
        else:
            outputdir=opts.outputdir
        if opts.read_length is None:
            read_length=100
        else:
            read_length=int(opts.read_length)
        if opts.insert_size is None:
            insert_size=350
        else:
            insert_size=int(opts.insert_size)
        if opts.dev is None:
            dev=50.0
        else:
            dev=float(opts.dev)
        if opts.paired_support is None:
            paired_support=6
        else:
            paired_support=int(opts.paired_support)
        if opts.split_support is None:
            split_support=2
        else:
            split_support=int(opts.split_support)
        if opts.thread is None:
            thread=1
        else:
            thread=int(opts.thread)
        if opts.exclude_region is None:
            exclude_region=''
        else:
            exclude_region=opts.exclude_region
        process=[]
        count=0
        if bwa_map=='aln':
            if meerkat_pathway=='':
                meerkat_result=[]
            else:
                t=multiprocessing.Process(target=meerkat_exe,args=(bamfile,ref,inputdir,outputdir,meerkat_pathway,samtools,bwa,repeat,str(max(thread-5,1)),readgroup,meerkat_exe_path,bwa_map))
                process.append(t)
                count=count+1
        else:
            if lumpy=='':
                lumpy_result=[]
            else:
                
                t=multiprocessing.Process(target=lumpy_exe,args=(bamfile,inputdir,outputdir+'/'+'tmp5',samtools,lumpy))
                process.append(t)
                count=count+1
            if meerkat_pathway=='':
                meerkat_result=[]
            else:
                t=multiprocessing.Process(target=meerkat_exe,args=(bamfile,ref,inputdir,outputdir,meerkat_pathway,samtools,bwa,repeat,str(max(thread-4,1)),readgroup,meerkat_exe_path,bwa_map))
                process.append(t)
                count=count+1
        if break_pathway_cpp=='':
            break_result=[]
        else:
            t=multiprocessing.Process(target=breakdancer_exe_BIC,args=(bamfile,inputdir,outputdir,break_pathway_perl,break_pathway_cpp,ref_dic,genotype,norm,samtools_unique,read_length,insert_size,chr_tag,delly_pathway,ref,bcftools,exclude_region,multiRG,'DUP'))
            process.append(t)
            count=count+1  
        if delly_pathway=='':
            delly_result=[]
        else:
            if os.path.exists(outputdir):
                if os.path.exists(outputdir+'/'+'tmp2'):
                    pass
                else:
                    os.makedirs(outputdir+'/'+'tmp2')
            else:
                os.makedirs(outputdir+'/'+'tmp2')
            sv_type=[['DEL','INV'],['TRA']]
            nloops=range(len(sv_type))
            for i in nloops:
                t=multiprocessing.Process(target=delly_exe_thread,args=(bamfile,ref,inputdir,outputdir,delly_pathway,sv_type[i],exclude_region,bcftools,multiRG))
                process.append(t)
                count=count+1
        nloops1=range(count)
        for i in nloops1:
            process[i].start()
        for i in nloops1:
           process[i].join()
        if delly_pathway=='':
            delly_result=[]
        else:
            try:
                cmd5='cat '+outputdir+'/'+'tmp2/'+bamfile+'*.vcf > '+outputdir+'/'+'tmp2/'+bamfile.split('.')[0]+'_result.vcf'
                os.system(cmd5)
                delly_result=read_delly(bamfile.split('.')[0]+'_result.vcf',outputdir+'/'+'tmp2',outputdir,paired_support,split_support)
            except:
                delly_result=[]
        if bwa_map=='aln':
            if meerkat_pathway=='':
                meerkat_result=[]
            else:
                tmp_name=bamfile.split('.')
                tmp_name[-1]='variants'
                tmp_name1='.'.join(tmp_name)
                meerkat_result=read_meerkat(tmp_name1,outputdir+'/'+'tmp3',outputdir,paired_support,split_support,chr_tag)
        else:
            if lumpy==[]:
                lumpy_result=[]
            else:
                lumpy_result=read_lumpy(bamfile.split('.')[0]+'.vcf',outputdir+'/tmp5',paired_support,split_support)
                #lumpy_result=[]
            if meerkat_pathway=='':
                meerkat_result=[]
            else:
                tmp_name=bamfile.split('.')
                tmp_name[-1]='variants'
                tmp_name1='.'.join(tmp_name)
                meerkat_result=read_meerkat(tmp_name1,outputdir+'/'+'tmp3',outputdir,paired_support,split_support,chr_tag)
        if break_pathway_cpp=='':
            break_result=[]
        else:
            break_result=read_breakdancer(bamfile.split('.')[0]+'_result.txt',outputdir+'/'+'tmp1',outputdir,paired_support)
        if bwa_map=='aln':
            result=compare_twofile(meerkat_result,delly_result,break_result)
        else:
            result=compare_fourfile(meerkat_result,delly_result,break_result,lumpy_result)
        ref_seq=reference1(ref)
        svmine_filter(result,bamfile,inputdir,outputdir,ref_dic,ref,genotype,norm,samtools_unique,read_length,insert_size,chr_tag,ref_seq)
    time_end_total=time.time()
    elapsed_total=time_end_total-time_total
    cmd='rm *.fa'
    os.system(cmd)
    cmd='rm *.txt'
    os.system(cmd)
    #print ("Time taken: ", elapsed_total, "seconds.")         
    #print 'all done at:',ctime()

main()
        
        
  
